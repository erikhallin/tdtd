#ifndef SOUND_LIST_H
#define SOUND_LIST_H

//List of all in game sounds

enum sounds
{
    wav_song1=0,
    wav_clicker,
    wav_gameover,
    wav_place_tower,
    wav_place_wall,
    wav_ship_fire,
    wav_ship_land,
    wav_ship_takeoff,
    wav_start,
    wav_supply_delivery,
    wav_supply_pickup,
    wav_tower_fire,
    wav_pixel_hit,
    wav_speed_up,
    wav_speed_down
};

#endif
