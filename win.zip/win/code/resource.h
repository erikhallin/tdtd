#ifndef RESOURCE_H
#define RESOURCE_H

#define IDI_TD       1000

#endif

